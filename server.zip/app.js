const express = require('express')
const cors = require('cors')
const app = express()
const userRouter = require('./router/user')
const goodsRouter = require('./router/goods')
app.listen(1270,()=>{
    console.log(`
        服务器已开启：http://127.0.0.1:1270


        获取商品数据接口(get):http://127.0.0.1:1270/goods/list
        用户登录接口(post):http://127.0.0.1:1270/user/login
        用户注册(查找用户名）接口(post):http://127.0.0.1:1270/user/register
        用户添加接口(post):http://127.0.0.1:1270/user/add
        解析token接口(get):http://127.0.0.1:1270/user/token
        验证码接口(get):http://127.0.0.1:1270/user/code
        修改密码(查找用户名接口)(post):http://127.0.0.1:1270/user/password/find
        密码修改接口(post):http://127.0.0.1:1270/user/Password/set
        获取数据库数据接口(get):http://127.0.0.1:1270/user/database/find
        删除数据库数据接口(post):http://127.0.0.1:1270/user/database/del  
        数据库禁用用户接口(post):http://127.0.0.1:1270/user/database/ban
        




        最后祝您身体健康
    `)
})

app.use(express.urlencoded())

app.use(cors())

app.use(userRouter)

app.use(goodsRouter)
