// 引入操作MongoDB数据库的包
const mongoose = require('mongoose')

// 链接数据库
mongoose.connect('mongodb://127.0.0.1:27017/lwx').then(()=>{
    console.log('数据库连接成功')
})

// 基于mongoose创建一个表结构（就是对咱们集合字段的一些约束）
const logins = new mongoose.Schema({
    username: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    phonenumber:{
        type: String,
    },
    state:{
        type: String,
    }
})

// 创建一个表模型（就是用于操作数据库里面数据增删改查）
const model = mongoose.model('login', logins)

// 导出，在其他的地方使用
module.exports = model

