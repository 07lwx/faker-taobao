const express = require('express')

const router = express.Router()

const fs = require('fs')

router.get('/goods/list',(req,res)=>{
    fs.readFile('./js/goods.json','utf-8',(err,data)=>{
        res.send(data)
    })
})



module.exports = router