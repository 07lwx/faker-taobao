const express = require('express')

const router = express.Router()

const model = require('../db/database')

const jwt = require('jsonwebtoken')

const svgCaptcha = require('svg-captcha')

router.post('/user/login', (req, res)=>{
    const { username, password } = req.body
    let token = jwt.sign({username}, 'lwx', {expiresIn: '1h'})
    model.find({username, password}, {'_id': 0, 'age': 0, '__v': 0}).then(data=>{
        if(!data.length){
            res.send({code: 0, message: '用户名或者密码错误'})
        }else{
            res.send({code: 1, message: '登录成功', token})
        }
    })
})

router.post('/user/register',(req,res)=>{
    const {username} = req.body
    model.find({username}).then(data=>{
        if(!data.length){
            res.send({code:1,message:'该用户名可以使用'})
        }else{
            res.send({code:0,message:'用户名太受欢迎请换一个'})
        }
    })
})

router.post('/user/add',(req,res)=>{
    const{username,password,phonenumber} = req.body
    model.insertMany({'username':username,'password':password,'phonenumber':phonenumber,'state':1})
    model.find({username}).then(data =>res.send(data))
    
})

router.get('/user/token', (req, res)=>{
    //    console.log(req.headers.authorization)
    jwt.verify(req.headers.authorization, 'lwx', (err, token)=>{
        // console.log(token)
        if(!token){
            res.send({code: 0, message: '您还没有登录'})
        }else{
            res.send({code: 1, message: 'ok', info:token})
        }
    })
})

router.get('/user/code',(req,res)=>{
    const cap = svgCaptcha.createMathExpr({
        color:true,
        noise:20
    })
    res.send(cap)
})

router.post('/user/password/find',(req,res)=>{
    const {username} = req.body
    model.find({username}).then(data=>{
        // console.log(data)
        if(data.length){
            res.send({code:1,message:'该用户名存在',data})
        }else{
            res.send({code:0,message:'该用户名不存在！请重新输入'})
        }  
    })
})
router.post('/user/password/set',(req,res)=>{
    const {username,password,state} = req.body
    model.updateMany({'username':username},{$set:{'password':password,'state':state}}).then(data=>{
        res.send({code:1,message:'修改完成'})
    })
})
router.get('/user/database/find',(req,res)=>{
    model.find({},{_id:0,__v:0}).then(data=>{
       res.send(data)
    })
})
router.post('/user/database/del',(req,res)=>{
    const {username} = req.body
    model.deleteMany({'username':username}).then(data=>{
        res.send({code:1,message:'删除成功'})
    })
})
router.post('/user/database/ban',(req,res)=>{
    const {username,state} = req.body
    model.updateMany({'username':username},{$set:{'state':state}}).then(data=>{
        res.send({code:1,message:'修改完成'})
    })
})

module.exports = router